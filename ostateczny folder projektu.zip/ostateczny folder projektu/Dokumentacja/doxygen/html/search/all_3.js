var searchData=
[
  ['predator_0',['Predator',['../classprojekt_1_1animal_1_1_predator.html',1,'projekt::animal']]],
  ['prey_1',['Prey',['../classprojekt_1_1animal_1_1_prey.html',1,'projekt::animal']]]
];
