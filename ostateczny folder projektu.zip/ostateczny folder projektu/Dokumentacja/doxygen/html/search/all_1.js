var searchData=
[
  ['follow_0',['follow',['../classprojekt_1_1animal_1_1_predator.html#a5f82582dc08aa814858bab800e9667e4',1,'projekt::animal::Predator']]]
];
