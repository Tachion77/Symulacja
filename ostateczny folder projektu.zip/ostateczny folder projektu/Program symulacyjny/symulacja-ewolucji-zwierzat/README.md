# symulacja-ewolucji-zwierz-t
projekt na programowanie obiektowe
